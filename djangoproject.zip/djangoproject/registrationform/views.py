from django.shortcuts import render

def homepage(request):
    return render(request,'registrationform.html')



def form(request):
    print(request.method)
    print(request.POST)
    a=(request.POST["firstname"])+(request.POST["middlename"])+(request.POST["lastname"])
    return render(request,'done.html',{'myname':a})
