from django.urls import path
from . import views

urlpatterns = [
    path('regis',views.homepage,name="registrationform"),
    path('formprocessing',views.form,name="form"),
]